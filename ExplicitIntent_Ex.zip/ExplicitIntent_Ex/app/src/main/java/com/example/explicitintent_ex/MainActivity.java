package com.example.explicitintent_ex;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Button b_register,b_login;

    EditText e_user, e_pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        b_login = findViewById(R.id.m_b_login);
        b_register =findViewById(R.id.m_b_register);
        e_user =findViewById(R.id.m_e_Username);
        e_pass =findViewById(R.id.m_e_Password);

        b_login.setOnClickListener(v->) {
            String user = e_user.getText().toString();
            String pass = e_user.getText().toString();

            if (user.equals("priya"))
            {
                Intent data = new Intent(MainActivity.this, dashboard.class);
                data.putExtra("user", user);
                data.putExtra("pass", pass);
                startActivity(data);
            }
            else {
                Toast.makeText(context.this,text:"wrong username",Toast.LENGTH_SHORT).show();
            }

        };



    }
}