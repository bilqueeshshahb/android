package com.example.myrecyclerviewdemo;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recycler);

        List<Item>items = new ArrayList<Item>();

        items.add(new Item("John Wick","john.wick@email.com",R.drawable.a));
        items.add(new Item("robert j","robert.j@email.com",R.drawable.a));
        items.add(new Item("James gunn","james@email.com",R.drawable.a));
        items.add(new Item("ricky tales","ricky@email.com",R.drawable.a));
        items.add(new Item("micky mose","micky@email.com",R.drawable.a));
        items.add(new Item("leg p[iece","leg@email.com",R.drawable.a));
        items.add(new Item("pic war","pic@email.com",R.drawable.a));
        items.add(new Item("apple mac","apple@email.com",R.drawable.a));


        recyclerView.setLayoutManager(new LinearLayoutManager(this));
       recyclerView.setAdapter(new MyAdapter(getApplicationContext(),items));





    }
}