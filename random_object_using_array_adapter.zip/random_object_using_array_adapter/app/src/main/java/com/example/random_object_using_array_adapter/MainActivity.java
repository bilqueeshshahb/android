package com.example.random_object_using_array_adapter;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView list;
    ArrayList<String> arrayList;
    ArrayAdapter<String> arrayadapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list = findViewById(R.id.listView);
        arrayList = new ArrayList<>();
        arrayList.add("Mango");
        arrayList.add("Banana");
        arrayList.add("Grapes");
        arrayList.add("Guava");
        arrayList.add("Pineapple");
        arrayList.add("Apple");
        arrayList.add("WaterMelon");

        arrayList.add("Mango");
        arrayList.add("Banana");
        arrayList.add("Grapes");
        arrayList.add("Guava");
        arrayList.add("Pineapple");
        arrayList.add("Apple");
        arrayList.add("WaterMelon");

        arrayadapter = new ArrayAdapter<>(
                 MainActivity.this,
                android.R.layout.simple_list_item_1,
                arrayList
             );
        list.setAdapter(arrayadapter);






    }
}