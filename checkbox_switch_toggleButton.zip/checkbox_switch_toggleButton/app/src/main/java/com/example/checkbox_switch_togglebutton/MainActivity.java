package com.example.checkbox_switch_togglebutton;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    TextView tv;

    CheckBox cb;
    ToggleButton tb;

    Switch sw;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        tv = findViewById(R.id.textView);
        cb = findViewById(R.id.checkbox);
        tb = findViewById(R.id.toggleButton);
        sw = findViewById(R.id.switchBtn);




        //cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
           // @Override
           // public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                //if (isChecked) {
                   // tv.setTextSize(30);
               // } else {
                  //  tv.setTextSize(20);

               // }
           // }
       // });
        cb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cb.isChecked()){
                    tv.setTextSize(30);
                } else {
                    tv.setTextSize(20);


                }
            }
        });
        tb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    tv.setTextSize(30);
                } else {
                    tv.setTextSize(20);

                }

            }
        });
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    tv.setTextSize(30);
                } else {
                    tv.setTextSize(20);


                }
                }
        });


    }
}