package com.example.calculator;

import  android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    TextView solutionTv;
    double firstNum = 0;
    String operator = "";
    boolean isNewOp = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        solutionTv = findViewById(R.id.solution_tv);
    }



    public void onButtonClick(View view) {
        Button button = (Button) view;
        String buttonText = button.getText().toString();


        switch (buttonText) {
            case "C":
                solutionTv.setText("0");
                firstNum = 0;
                operator ="";
                isNewOp = true;
                break;

            case "+":
            case "-":
            case "*":
            case "/":
                firstNum = Double.parseDouble(solutionTv.getText().toString());
                operator = buttonText;
                isNewOp = true;
                break;
            case "=":
                if(operator.isEmpty()) return;
                double secondNum = Double.parseDouble(solutionTv.getText().toString());
                double result = 0;

                if (operator.equals("+")) result = firstNum + secondNum;
                else if(operator.equals("-")) result = firstNum - secondNum;
                else if (operator.equals("*")) result = firstNum * secondNum;
                else if(operator.equals("/")) {
                    if (secondNum != 0) result = firstNum / secondNum;
                    else {
                        solutionTv.setText("errors");
                        return;
                    }
                }

                solutionTv.setText(String.valueOf(result));
                operator ="";
                isNewOp = true;
                break;
            default:
                if (isNewOp ||  solutionTv.getText().toString().equals("0")){
                    solutionTv.setText(buttonText);
                }
                else
                {
                    solutionTv.append(buttonText);
                }
                isNewOp = false;

                break;
        }



    }
}

