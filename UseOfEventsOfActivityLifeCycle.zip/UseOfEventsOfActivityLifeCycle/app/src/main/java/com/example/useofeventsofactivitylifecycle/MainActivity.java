package com.your.packagename; // Replace with your actual package name

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    // Define a Tag for Logcat messages (optional but helpful)
    private static final String TAG = "LifecycleDemo";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Ensure you have a layout file named activity_main.xml

        // Display Toast message and log the event
        Toast.makeText(this, "onCreate() called", Toast.LENGTH_SHORT).show();
        Log.d(TAG, "onCreate() called");
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Display Toast message and log the event
        Toast.makeText(this, "onStart() called", Toast.LENGTH_SHORT).show();
        Log.d(TAG, "onStart() called");
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Display Toast message and log the event
        Toast.makeText(this, "onResume() called", Toast.LENGTH_SHORT).show();
        Log.d(TAG, "onResume() called");
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Display Toast message and log the event
        Toast.makeText(this, "onPause() called", Toast.LENGTH_SHORT).show();
        Log.d(TAG, "onPause() called");
    }

    @Override
    protected void onStop() {
        super.onStop();
        // Display Toast message and log the event
        Toast.makeText(this, "onStop() called", Toast.LENGTH_SHORT).show();
        Log.d(TAG, "onStop() called");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        // Display Toast message and log the event
        Toast.makeText(this, "onRestart() called", Toast.LENGTH_SHORT).show();
        Log.d(TAG, "onRestart() called");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Display Toast message and log the event
        Toast.makeText(this, "onDestroy() called", Toast.LENGTH_SHORT).show();
        Log.d(TAG, "onDestroy() called");
    }
}